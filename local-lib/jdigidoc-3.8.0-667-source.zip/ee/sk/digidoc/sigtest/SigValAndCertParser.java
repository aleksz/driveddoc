package ee.sk.digidoc.sigtest;
import ee.sk.digidoc.*;
import ee.sk.digidoc.factory.SAXDigiDocException;
import ee.sk.utils.ConvertUtils;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import java.security.cert.X509Certificate;
import org.apache.log4j.Logger;

/**
 * SAX implementation of SigValAndCertParser
 * A very simple xl-dsig or xades signature parser that returns
 * only SignatureValue and <X509Certificate> (signers cert)
 * @author  Veiko Sinivee
 * @version 1.0
 */
public class SigValAndCertParser
	extends DefaultHandler
{
	private StringBuffer m_sbValue;
	private byte [] m_bSigVal, m_bCert;
	private X509Certificate m_cert;
	/** log4j logger */
	private Logger m_logger = null;
	
	
	public byte[] getSigVal() { return m_bSigVal; }
	public byte[] getCertVal() { return m_bCert; }
	public X509Certificate getCert() { return m_cert; }
	
	/**
	 * Constructor for SigValAndCertParser
	 */
	public SigValAndCertParser()
	{
		m_logger = Logger.getLogger(SigValAndCertParser.class);
	}
	
	/*private InputStream removeDtd(InputStream is)
	{
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			byte[] data = new byte[2048];
			int n;
			while((n = is.read(data)) > 0)
				bos.write(data, 0, n);
			data = bos.toByteArray();
			bos.close();
			String s = new String(data);
			if(m_logger.isDebugEnabled())
				m_logger.debug("Manifest orig:\n------\n" + s + "\n------\n");
			data = null;
			int p1 = s.indexOf("<!DOCTYPE");
			int p2 = 0;
			if(p1 > 0) {
				p2 = s.indexOf(">", p1);
				if(p2 > 0) {
					String s2 = s.substring(0, p1) + s.substring(p2+1);
					if(m_logger.isDebugEnabled())
						m_logger.debug("Manifest no-dtd:\n------\n" + s2 + "\n------\n");
					return new ByteArrayInputStream(s2.getBytes());
				}
			} else
				return new ByteArrayInputStream(s.getBytes());
		} catch(Exception ex) {
			m_logger.error("Error removing dtd: " + ex);
		}
		return is;
	}*/
	
	/**
	 * Reads in a manifest.xml file
	 * @param fname opened stream with manifest.xml data
	 * The user must open and close it.
	 * @return Manifest object if successfully parsed
	 */
	public boolean readSigValAndCert(String fname)
		throws DigiDocException 
	{
		// Use an instance of ourselves as the SAX event handler
		SigValAndCertParser handler = this;
		// Use the default (non-validating) parser
		SAXParserFactory factory = SAXParserFactory.newInstance();
		
		if(m_logger.isDebugEnabled())
			m_logger.debug("Start reading manifest.xml");
		try {
			factory.setValidating(false);
			//factory.setFeature("http://xml.org/sax/features/validation", false);
			//factory.setFeature("http://xml.org/sax/features/resolve-dtd-uris", false);
			SAXParser saxParser = factory.newSAXParser();
			FileInputStream fis = new FileInputStream(fname);
			//InputStream is2 = removeDtd(is);
			saxParser.parse(fis, handler);
		} catch (SAXDigiDocException ex) {
			throw ex.getDigiDocException();
		} catch (Exception ex) {
			DigiDocException.handleException(ex, DigiDocException.ERR_PARSE_XML);
		}
		return m_bSigVal != null && m_bCert != null;
	}
	
	/**
	 * Start Document handler
	 */
	public void startDocument() throws SAXException {
		
	}
	
	/**
	 * End Document handler
	 */
	public void endDocument() throws SAXException {
		
	}
	
	/**
	 * Start Element handler
	 * @param namespaceURI namespace URI
	 * @param lName local name
	 * @param qName qualified name
	 * @param attrs attributes
	 */
	public void startElement(String namespaceURI, String lName, String qName, Attributes attrs)
		throws SAXDigiDocException
	{
		if(m_logger.isDebugEnabled())
			m_logger.debug("Start Element: "	+ qName + " lname: "  + lName + " uri: " + namespaceURI);
		//m_tags.push(qName);
		String tag = qName;
		int p1 = tag.indexOf(':');
		if(p1 > 0)
			tag = qName.substring(p1+1);
		// <manifest>
		if(tag.equals("SignatureValue") ||
		   tag.equals("X509Certificate")) {
			m_sbValue = new StringBuffer();
		}
		
	}
	
	/**
	 * End Element handler
	 * @param namespaceURI namespace URI
	 * @param lName local name
	 * @param qName qualified name
	 */
	public void endElement(String namespaceURI, String sName, String qName)
		throws SAXException 
	{
		//if(m_logger.isDebugEnabled())
		//	m_logger.debug("End Element: " + qName + " collect: " + m_nCollectMode);
		String tag = qName;
		int p1 = tag.indexOf(':');
		if(p1 > 0)
			tag = qName.substring(p1+1);
		if(tag.equals("SignatureValue")) {
			if(m_sbValue != null) {
				m_bSigVal = Base64Util.decode(m_sbValue.toString());
				
			}
		}
		if(tag.equals("X509Certificate")) {
			if(m_sbValue != null) {
				m_bCert = Base64Util.decode(m_sbValue.toString());
				try  {
				if(m_bCert != null)
					m_cert = SignedDoc.readCertificate(m_bCert);
				} catch(DigiDocException ex) {
					m_logger.error("Error parsing cert: " + ex);
				}
			}
		}
		
		
	}
	
	/**
	 * SAX characters event handler
	 * @param buf received bytes array
	 * @param offset offset to the array
	 * @param len length of data
	 */
	public void characters(char buf[], int offset, int len)
		throws SAXException 
    {
		String s = new String(buf, offset, len);
        if (s != null) {		
			if (m_sbValue != null)
				m_sbValue.append(s);
		}
	}
}

