package ee.sk.digidoc.sigtest;
import ee.sk.utils.*;
import java.security.Provider;
import java.security.Security;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;


/**
 * Utility to read any xml file that contains a signature,
 * extract signature value and signers cert and test signature value 
 * contents regarding to pkcs1 padding and asn.1 structure prefix used.
 * @author Veiko Sinivee
 */
public class SigTest1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String sFile = args[0];
		try {
			System.out.println("Reading file: " + sFile);
			SigValAndCertParser parser = new SigValAndCertParser();
			parser.readSigValAndCert(sFile);
			byte[] sigval = parser.getSigVal();
			X509Certificate cert = parser.getCert();
			//System.out.println("SigVal len: " + ((sigval != null) ? sigval.length : 0) + "\n---\n" + ConvertUtils.bin2hex(sigval) + "\n---\n");
			Provider prv = (Provider)Class.forName("org.bouncycastle.jce.provider.BouncyCastleProvider").newInstance();
            Security.addProvider(prv);
			Cipher cryptoEngine = Cipher.getInstance("RSA//", "BC");
	        cryptoEngine.init(Cipher.DECRYPT_MODE, cert);
	        byte[] ddigest = cryptoEngine.doFinal(sigval);
	        System.out.println("Decrypted digest: \'" + ConvertUtils.bin2hex(ddigest) + "\' len: " + ddigest.length);
	        int n1 = 0, n2 = 0, l1 = 0, l2 = 0, l3 = 0;
	        for(int i = 0; (ddigest != null) && (i < ddigest.length); i++) {
	        	byte b = ddigest[i];
	        	//System.out.println("Byte at: " + i + " - " + b);
	        	if((l1 == 0 && l2 == 0 && b == 1) ||
	        		(l1 > 0 && b == -1 && n1 == 0) ||
	        		(l1 > 0 && b == 0x00 && n1 == 0))
	        		l1++;
	        	if(l1 > 0 && b == 0x00) {
	        		n1 = i+1;
	        		l2 = 1;
	        	}
	        }
	        if(ddigest != null && ddigest.length < 129) {
	        	l3 = 20;
	        	l2 = ddigest.length - l3 - l1;
	        }
	        System.out.println("Padding: " + l1 + " pref: " + l2 + " hash: " + l3);
	        
		} catch(Exception ex) {
			System.err.println("Error: " + ex);
			ex.printStackTrace();
		}

	}

}
