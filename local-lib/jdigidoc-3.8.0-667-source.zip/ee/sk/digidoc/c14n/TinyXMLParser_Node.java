package ee.sk.digidoc.c14n;

import ee.sk.digidoc.c14n.TinyXMLParser_Element;

public abstract class TinyXMLParser_Node
{
    public TinyXMLParser_Element Parent;


    protected TinyXMLParser_Node()
    {
    }


    public void ToConsole()
    {
    }

}
